const router = new VueRouter({
    mode: 'history',
    base: __dirname,
    hashbang: false,
    history: true,
})

export default router