<template>
    <div>
       ss
    </div>
</template>
<script>
export default {
    name: 'app', 
    data() {
        let localdata = {}
        return {
            localdata,
            isvariety: false,
        }
    },
}
</script>